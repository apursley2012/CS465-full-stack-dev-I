var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');


// Define routers
var indexRouter = require('./app_server/routes/index');
var travelRouter = require('./app_server/routes/travel');
var userRouter = require('./app_server/routes/user'); 
var apiRouter = require('./app_server/routes/api');

var handlebars = require('hbs');

// Bring in the database connection
require('./app_server/models/db');

var app = express();

// View engine setup
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// Register handlebars partials (https://www.nomjs.com/packages/hbs)
handlebars.registerPartials(__dirname + '/app_server/views/partials');

app.set('view engine', 'hbs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Wire-up routes to controllers
app.use('/', indexRouter);
app.use('/user', userRouter);
app.use('/', travelRouter);
app.use('/api', apiRouter); 

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
